<!DOCTYPE html>
	<html dir="ltr" lang="en-US" prefix="og: https://ogp.me/ns#">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; Olami &#8212; WordPress</title>
	<meta name='robots' content='max-image-preview:large, noindex, noarchive' />
<link rel='dns-prefetch' href='//www.google.com' />
<script type="text/javascript" src="https://www.google.com/recaptcha/api.js?render=6Lf6UMcpAAAAALIW5iK-LdyxL6Eoo_sE_6lWwANJ&amp;ver=6.8.1" id="wordfence-ls-recaptcha-js"></script>
<script type="text/javascript" src="https://olami.com.ng/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://olami.com.ng/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" id="wordfence-ls-login-js-extra">
/* <![CDATA[ */
var WFLS_LOGIN_TRANSLATIONS = {"Message to Support":"Message to Support","Send":"Send","An error was encountered while trying to send the message. Please try again.":"An error was encountered while trying to send the message. Please try again.","<strong>ERROR<\/strong>: An error was encountered while trying to send the message. Please try again.":"<strong>ERROR<\/strong>: An error was encountered while trying to send the message. Please try again.","Login failed with status code 403. Please contact the site administrator.":"Login failed with status code 403. Please contact the site administrator.","<strong>ERROR<\/strong>: Login failed with status code 403. Please contact the site administrator.":"<strong>ERROR<\/strong>: Login failed with status code 403. Please contact the site administrator.","Login failed with status code 503. Please contact the site administrator.":"Login failed with status code 503. Please contact the site administrator.","<strong>ERROR<\/strong>: Login failed with status code 503. Please contact the site administrator.":"<strong>ERROR<\/strong>: Login failed with status code 503. Please contact the site administrator.","Wordfence 2FA Code":"Wordfence 2FA Code","Remember for 30 days":"Remember for 30 days","Log In":"Log In","<strong>ERROR<\/strong>: An error was encountered while trying to authenticate. Please try again.":"<strong>ERROR<\/strong>: An error was encountered while trying to authenticate. Please try again.","The Wordfence 2FA Code can be found within the authenticator app you used when first activating two-factor authentication. You may also use one of your recovery codes.":"The Wordfence 2FA Code can be found within the authenticator app you used when first activating two-factor authentication. You may also use one of your recovery codes."};
var WFLSVars = {"ajaxurl":"\/wp-admin\/admin-ajax.php","nonce":"1cdb692067","recaptchasitekey":"6Lf6UMcpAAAAALIW5iK-LdyxL6Eoo_sE_6lWwANJ","useCAPTCHA":"1","allowremember":"1","verification":null};
/* ]]> */
</script>
<script type="text/javascript" src="https://olami.com.ng/wp-content/plugins/wordfence/modules/login-security/js/login.1744125809.js?ver=1.1.15" id="wordfence-ls-login-js"></script>
<link rel='stylesheet' id='dashicons-css' href='https://olami.com.ng/wp-includes/css/dashicons.min.css?ver=6.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css' href='https://olami.com.ng/wp-includes/css/buttons.min.css?ver=6.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css' href='https://olami.com.ng/wp-admin/css/forms.min.css?ver=6.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css' href='https://olami.com.ng/wp-admin/css/l10n.min.css?ver=6.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='login-css' href='https://olami.com.ng/wp-admin/css/login.min.css?ver=6.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='wordfence-ls-login-css' href='https://olami.com.ng/wp-content/plugins/wordfence/modules/login-security/css/login.1744125809.css?ver=1.1.15' type='text/css' media='all' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="icon" href="https://olami.com.ng/wp-content/uploads/2020/02/cropped-Asset-62x-32x32.png" sizes="32x32" />
<link rel="icon" href="https://olami.com.ng/wp-content/uploads/2020/02/cropped-Asset-62x-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://olami.com.ng/wp-content/uploads/2020/02/cropped-Asset-62x-180x180.png" />
<meta name="msapplication-TileImage" content="https://olami.com.ng/wp-content/uploads/2020/02/cropped-Asset-62x-270x270.png" />
	</head>
	<body class="login no-js login-action-login wp-core-ui  locale-en-us">
	<script type="text/javascript">
/* <![CDATA[ */
document.body.className = document.body.className.replace('no-js','js');
/* ]]> */
</script>

				<h1 class="screen-reader-text">Log In</h1>
			<div id="login">
		<h1 role="presentation" class="wp-login-logo"><a href="https://wordpress.org/">Powered by WordPress</a></h1>
	
		<form name="loginform" id="loginform" action="https://olami.com.ng/wp-login.php" method="post">
			<p>
				<label for="user_login">Username or Email Address</label>
				<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" autocomplete="username" required="required" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">Password</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" class="input password-input" value="" size="20" autocomplete="current-password" spellcheck="false" required="required" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Show password">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
						<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> <label for="rememberme">Remember Me</label></p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
									<input type="hidden" name="redirect_to" value="https://olami.com.ng/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
				<a class="wp-login-register" href="https://olami.com.ng/wp-login.php?action=register">Register</a> | <a class="wp-login-lost-password" href="https://olami.com.ng/wp-login.php?action=lostpassword">Lost your password?</a>			</p>
			<script type="text/javascript">
/* <![CDATA[ */
function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }
/* ]]> */
</script>
		<p id="backtoblog">
			<a href="https://olami.com.ng/">&larr; Go to Olami</a>		</p>
			</div>
		
	<script type="text/javascript" src="https://olami.com.ng/wp-includes/js/clipboard.min.js?ver=2.0.11" id="clipboard-js"></script>
<script type="text/javascript" id="zxcvbn-async-js-extra">
/* <![CDATA[ */
var _zxcvbnSettings = {"src":"https:\/\/olami.com.ng\/wp-includes\/js\/zxcvbn.min.js"};
/* ]]> */
</script>
<script type="text/javascript" src="https://olami.com.ng/wp-includes/js/zxcvbn-async.min.js?ver=1.0" id="zxcvbn-async-js"></script>
<script type="text/javascript" src="https://olami.com.ng/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://olami.com.ng/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
/* ]]> */
</script>
<script type="text/javascript" id="password-strength-meter-js-extra">
/* <![CDATA[ */
var pwsL10n = {"unknown":"Password strength unknown","short":"Very weak","bad":"Weak","good":"Medium","strong":"Strong","mismatch":"Mismatch"};
/* ]]> */
</script>
<script type="text/javascript" src="https://olami.com.ng/wp-admin/js/password-strength-meter.min.js?ver=6.8.1" id="password-strength-meter-js"></script>
<script type="text/javascript" src="https://olami.com.ng/wp-includes/js/underscore.min.js?ver=1.13.7" id="underscore-js"></script>
<script type="text/javascript" id="wp-util-js-extra">
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://olami.com.ng/wp-includes/js/wp-util.min.js?ver=6.8.1" id="wp-util-js"></script>
<script type="text/javascript" src="https://olami.com.ng/wp-includes/js/dist/dom-ready.min.js?ver=f77871ff7694fffea381" id="wp-dom-ready-js"></script>
<script type="text/javascript" src="https://olami.com.ng/wp-includes/js/dist/a11y.min.js?ver=3156534cc54473497e14" id="wp-a11y-js"></script>
<script type="text/javascript" id="user-profile-js-extra">
/* <![CDATA[ */
var userProfileL10n = {"user_id":"0","nonce":"d7cae041ec"};
/* ]]> */
</script>
<script type="text/javascript" src="https://olami.com.ng/wp-admin/js/user-profile.min.js?ver=6.8.1" id="user-profile-js"></script>
	</body>
	</html>
	