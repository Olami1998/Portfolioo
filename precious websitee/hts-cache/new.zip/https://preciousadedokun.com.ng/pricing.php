  <!-- Bootstrap Icons CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet" />
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .dotted-bg {
      background-size: 10px 10px;
      border-radius: 12px;
    }
    #loadin {
      opacity: 0;
      transition: opacity 0.4s ease-in-out;
      white-space: pre-wrap;
    }
    #loadin.visible { opacity: 1; }
    #preloader { transition: opacity 0.2s ease; }
  </style>
<body class="bg-gray-100 dark:bg-gray-900 transition-colors duration-500">

<nav 
  id="navbar"
  class="fixed top-[30px] left-1/2 transform -translate-x-1/2 w-[90vw] max-w-6xl
         dotted-bg 
         bg-white/30 dark:bg-gray-900/40 
         backdrop-blur-md
         border-gray-500/50 dark:border-gray-400/50
         shadow-lg
         flex items-center justify-between px-6 py-3
         z-50
         transition-colors duration-500
         rounded-xl"
>
  <!-- Logo -->
  <a href="/" class="text-2xl font-extrabold text-gray-900 dark:text-white flex items-center gap-2">
    <i class="bi bi-code-slash"></i> AP.
  </a>

  <!-- Nav Links (centered properly) -->
  <div class="flex-1 flex justify-center">
    <ul class="hidden md:flex gap-8 text-gray-800 dark:text-gray-300 font-semibold">
      <li><a href="/" class="hover:text-teal-500 dark:hover:text-teal-400 transition">Home</a></li>
      <li><a href="/projects" class="hover:text-teal-500 dark:hover:text-teal-400 transition">Projects</a></li>
      <li><a href="/contact" class="hover:text-teal-500 dark:hover:text-teal-400 transition">Contact</a></li>
      <li><a href="https://blog.preciousadedokun.com.ng" class="hover:text-teal-500 dark:hover:text-teal-400 transition">Blog</a></li>
      <li><a href="/github" class="hover:text-teal-500 dark:hover:text-teal-400 transition">Github</a></li>
    </ul>
  </div>

  <!-- Right Controls -->
  <div class="flex items-center gap-4">
    <!-- Dark/Light Mode -->
    <button id="themeToggle" aria-label="Toggle Dark Mode" 
      class="text-gray-800 dark:text-gray-200 hover:text-teal-500 dark:hover:text-teal-400 transition text-xl">
      <i id="themeIcon" class="bi bi-moon-fill"></i>
    </button>

    <!-- Mobile Hamburger -->
    <button id="menuToggle" aria-label="Toggle Menu" class="md:hidden text-gray-800 dark:text-gray-200 text-2xl">
      <i class="bi bi-list"></i>
    </button>
  </div>
</nav>
<!-- Mobile Menu -->
<div id="mobileMenu" class="fixed top-[90px] left-1/2 transform -translate-x-1/2 w-[90vw] max-w-6xl
  bg-white/90 dark:bg-gray-900/90
  backdrop-blur-md
  border border-gray-400/40 dark:border-gray-500/40
  rounded-xl
  shadow-lg
  p-6
  space-y-4
  md:hidden
  hidden
  z-40">
  <a href="/" class="block text-gray-900 dark:text-gray-100 font-semibold text-lg hover:text-teal-500 dark:hover:text-teal-400 transition">Home</a>
  <a href="/projects" class="block text-gray-900 dark:text-gray-100 font-semibold text-lg hover:text-teal-500 dark:hover:text-teal-400 transition">Projects</a>
  <a href="/contact" class="block text-gray-900 dark:text-gray-100 font-semibold text-lg hover:text-teal-500 dark:hover:text-teal-400 transition">Contact</a>
  <a href="https://blog.preciousadedokun.com.ng" target="_blank" rel="noopener" class="block text-gray-900 dark:text-gray-100 font-semibold text-lg hover:text-teal-500 dark:hover:text-teal-400 transition">Blog</a>
  <a href="/github" class="block text-gray-900 dark:text-gray-100 font-semibold text-lg hover:text-teal-500 dark:hover:text-teal-400 transition">Github</a>
</div>

<!-- JS -->
<script>
  const themeToggleBtn = document.getElementById('themeToggle');
  const themeIcon = document.getElementById('themeIcon');
  const htmlElement = document.documentElement;
  const storedTheme = localStorage.getItem('theme');
  const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

  if (storedTheme === 'dark' || (!storedTheme && systemPrefersDark)) {
    htmlElement.classList.add('dark');
    themeIcon.className = 'bi bi-sun-fill';
  } else {
    htmlElement.classList.remove('dark');
    themeIcon.className = 'bi bi-moon-fill';
  }

  themeToggleBtn.addEventListener('click', () => {
    if (htmlElement.classList.contains('dark')) {
      htmlElement.classList.remove('dark');
      themeIcon.className = 'bi bi-moon-fill';
      localStorage.setItem('theme', 'light');
    } else {
      htmlElement.classList.add('dark');
      themeIcon.className = 'bi bi-sun-fill';
      localStorage.setItem('theme', 'dark');
    }
  });

  const menuToggleBtn = document.getElementById('menuToggle');
  const mobileMenu = document.getElementById('mobileMenu');
  menuToggleBtn.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
  });
</script>

<!-- Spacer to prevent content hiding under navbar -->
<div style="height: 100px;"></div>
</body><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Affordable Web & App Development Pricing in Nigeria | Precious Adedokun</title>
  <meta name="description" content="Explore affordable website, PWA, and mobile app development pricing packages by Precious Adedokun — the best web developer in Nigeria. From corporate websites to full mobile apps and staff systems." />
  <meta name="keywords" content="web development pricing Nigeria, website design packages Lagos, affordable app developer Nigeria, mobile app developer, PWA developer, staff management system, Precious Adedokun, APCodeSphere" />
  <meta name="author" content="Precious Adedokun" />
  <link rel="canonical" href="https://preciousadedokun.com.ng/pricing" />

  <!-- Lucide Icons -->
  <script src="https://unpkg.com/lucide@latest"></script>

  <!-- Schema FAQ -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "How much does a corporate website cost in Nigeria?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "A corporate website package costs ₦300,000 and includes domain, hosting, up to 5 pages, logo design, business emails, and on-page SEO."
        }
      },
      {
        "@type": "Question",
        "name": "How much does an e-commerce website cost in Nigeria?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "The e-commerce web development package costs ₦500,000 and includes unlimited pages, payment gateway, analytics, support, and SEO optimization."
        }
      },
      {
        "@type": "Question",
        "name": "What is included in the premium web development package?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "The premium plan includes domain, hosting, dashboards, payment gateway, analytics, social media integration, and full SEO management."
        }
      },
      {
        "@type": "Question",
        "name": "How much does a PWA or startup app cost?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Startup PWA apps cost ₦400,000. They’re installable web apps that work on Android and iOS with push notifications and offline support."
        }
      },
      {
        "@type": "Question",
        "name": "How much does a full mobile app cost in Nigeria?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Full mobile app development starts at ₦800,000, including Android and iOS versions, backend API, admin dashboard, and store deployment."
        }
      },
      {
        "@type": "Question",
        "name": "Do you develop staff systems or business dashboards?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Yes. Staff system packages start at ₦600,000 and include dashboards, attendance, payroll, reports, and secure admin access."
        }
      }
    ]
  }
  </script>

  <!-- Schema: WebPage & Organization -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Pricing – Precious Adedokun",
    "url": "https://preciousadedokun.com.ng/pricing",
    "description": "Affordable web and app development pricing by Precious Adedokun, the best web developer in Nigeria.",
    "publisher": {
      "@type": "Person",
      "name": "Precious Adedokun",
      "url": "https://preciousadedokun.com.ng"
    }
  }
  </script>

  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Precious Adedokun",
    "url": "https://preciousadedokun.com.ng",
    "logo": "https://preciousadedokun.com.ng/assets/img/logo.png",
    "sameAs": [
      "https://www.linkedin.com/in/preciousadedokun",
      "https://twitter.com/preciousadedokun",
      "https://github.com/preciousadedokun"
    ],
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+2349064779856",
      "email": "apreezofficial@gmail.com",
      "contactType": "Customer Support",
      "areaServed": "NG",
      "availableLanguage": "English"
    }
  }
  </script>

  <script>
    tailwind.config = { darkMode: 'class' };
  </script>
</head>

<body class="bg-gray-50 dark:bg-gray-900">

<section class="py-16">
  <div class="container mx-auto px-4 text-center">
    <h1 class="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
      Web & App Development Pricing in Nigeria
    </h1>
    <p class="text-lg text-gray-700 dark:text-gray-300 mb-10">
      Transparent pricing for <strong>websites, PWAs, mobile apps</strong>, and <strong>staff systems</strong> — built by <strong>Precious Adedokun</strong>.
    </p>
  </div>

  <!-- Website Plans -->
  <h2 class="text-2xl font-semibold text-center text-gray-800 dark:text-gray-200 mb-6">Website Development Packages</h2>
  <div class="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">

    <!-- Corporate -->
    <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-lg border border-gray-200 dark:border-gray-700 p-8 text-center hover:shadow-xl transition">
      <i data-lucide="briefcase" class="mx-auto mb-3 w-10 h-10 text-teal-600"></i>
      <h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-3">Corporate</h3>
      <p class="text-3xl font-extrabold text-teal-600 mb-2">₦300,000</p>
      <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">👔 Suitable for: Small Businesses, NGOs, and Startups</p>
      <ul class="text-gray-700 dark:text-gray-300 text-left space-y-2 mb-6">
        <li>✅ Domain & Hosting (1 Year)</li>
        <li>✅ Business Emails</li>
        <li>✅ Up to 5 Pages</li>
        <li>✅ Logo Design</li>
        <li>✅ On-Page SEO</li>
      </ul>
      <a href="/contact" class="bg-teal-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-teal-700 transition">Get Started</a>
    </div>

    <!-- E-Commerce -->
    <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-lg border-2 border-teal-600 transform scale-105 p-8 text-center hover:shadow-xl transition">
      <i data-lucide="shopping-cart" class="mx-auto mb-3 w-10 h-10 text-teal-600"></i>
      <h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-3">E-Commerce</h3>
      <p class="text-3xl font-extrabold text-teal-600 mb-2">₦500,000</p>
      <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">🛍️ Suitable for: Online Stores, Boutiques, and Retail Brands</p>
      <ul class="text-gray-700 dark:text-gray-300 text-left space-y-2 mb-6">
        <li>✅ Domain & Hosting (1 Year)</li>
        <li>✅ Payment Gateway</li>
        <li>✅ Unlimited Pages</li>
        <li>✅ SEO & Analytics</li>
        <li>✅ 1-Month Support</li>
      </ul>
      <a href="/contact" class="bg-teal-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-teal-700 transition">Get Started</a>
    </div>

    <!-- Premium -->
    <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-lg border border-gray-200 dark:border-gray-700 p-8 text-center hover:shadow-xl transition">
      <i data-lucide="crown" class="mx-auto mb-3 w-10 h-10 text-teal-600"></i>
      <h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-3">Premium</h3>
      <p class="text-3xl font-extrabold text-teal-600 mb-2">₦700,000</p>
      <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">🏢 Suitable for: Established Businesses & Enterprises</p>
      <ul class="text-gray-700 dark:text-gray-300 text-left space-y-2 mb-6">
        <li>✅ Domain & Hosting (1 Year)</li>
        <li>✅ Custom Dashboard</li>
        <li>✅ Payment Gateway</li>
        <li>✅ Continuous Support</li>
        <li>✅ Advanced SEO + Analytics</li>
      </ul>
      <a href="/contact" class="bg-teal-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-teal-700 transition">Get Started</a>
    </div>
  </div>

  <!-- App & System Plans -->
  <h2 class="text-2xl font-semibold text-center text-gray-800 dark:text-gray-200 mb-6">App & System Packages</h2>
  <div class="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">

    <!-- Startup PWA -->
    <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-lg border-2 border-teal-600 transform scale-105 p-8 text-center hover:shadow-xl transition">
      <i data-lucide="rocket" class="mx-auto mb-3 w-10 h-10 text-teal-600"></i>
      <h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-3">Startup PWA App</h3>
      <p class="text-3xl font-extrabold text-teal-600 mb-2">₦400,000</p>
      <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">🚀 Suitable for: Startups & Early-Stage Founders</p>
      <ul class="text-gray-700 dark:text-gray-300 text-left space-y-2 mb-6">
        <li>✅ Progressive Web App (Installable)</li>
        <li>✅ Works on Android & iOS</li>
        <li>✅ Push Notifications</li>
        <li>✅ Offline Support</li>
        <li>✅ 1-Month Support</li>
      </ul>
      <a href="/contact" class="bg-teal-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-teal-700 transition">Get Started</a>
    </div>

    <!-- Full Mobile App -->
    <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-lg border border-gray-200 dark:border-gray-700 p-8 text-center hover:shadow-xl transition">
      <i data-lucide="smartphone" class="mx-auto mb-3 w-10 h-10 text-teal-600"></i>
      <h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-3">Full Mobile App</h3>
      <p class="text-3xl font-extrabold text-teal-600 mb-2">₦800,000+</p>
      <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">📱 Suitable for: Established Startups & Businesses</p>
      <ul class="text-gray-700 dark:text-gray-300 text-left space-y-2 mb-6">
        <li>✅ Android & iOS Versions</li>
        <li>✅ Backend & API Integration</li>
        <li>✅ Admin Dashboard</li>
        <li>✅ Store Deployment</li>
        <li>✅ 2-Month Support</li>
      </ul>
      <a href="/contact" class="bg-teal-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-teal-700 transition">Get Started</a>
    </div>

    <!-- Staff System -->
    <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-lg border border-gray-200 dark:border-gray-700 p-8 text-center hover:shadow-xl transition">
      <i data-lucide="users" class="mx-auto mb-3 w-10 h-10 text-teal-600"></i>
      <h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-3">Staff System</h3>
      <p class="text-3xl font-extrabold text-teal-600 mb-2">₦600,000</p>
      <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">👥 Suitable for: Companies & HR Teams</p>
      <ul class="text-gray-700 dark:text-gray-300 text-left space-y-2 mb-6">
        <li>✅ Staff Dashboard & Login</li>
        <li>✅ Attendance & Payroll</li>
        <li>✅ Role Management</li>
        <li>✅ Reports & Analytics</li>
        <li>✅ Secure Admin Access</li>
      </ul>
      <a href="/contact" class="bg-teal-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-teal-700 transition">Get Started</a>
    </div>
  </div>

  <!-- Contact Info -->
  <div class="text-center mt-12 max-w-3xl mx-auto text-sm text-gray-600 dark:text-gray-400">
    <p>
      📞 Call or WhatsApp: <a href="tel:+2349064779856" class="text-teal-600 font-semibold">0906 477 9856</a><br />
      📧 Email: <a href="mailto:apreezofficial@gmail.com" class="text-teal-600 font-semibold">apreezofficial@gmail.com</a>
    </p>
    <p class="mt-4">
      By ordering our services, you agree to our 
      <a href="/terms" class="text-teal-600 underline">Terms of Service</a> and 
      <a href="/privacy" class="text-teal-600 underline">Privacy Policy</a>.
    </p>
  </div>
</section>

<footer class="text-gray-800 dark:text-[#EAEAEA] px-8 py-12 select-none transition-colors duration-300">
  <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center md:items-start gap-10 md:gap-0">

    <!-- Brand & SEO Description -->
    <div class="flex flex-col items-center md:items-start space-y-3 md:max-w-xs">
      <h2 class="text-4xl font-extrabold tracking-wide text-[#008080] hover:text-[#FF6F61] transition-colors cursor-default select-text">
        APCodeSphere
      </h2>
      <p class="text-gray-600 dark:text-gray-400 text-center md:text-left leading-relaxed">
        👑 Precious Adedokun — widely recognized as one of the <strong>best web developers in Nigeria</strong>, 
        delivering cutting-edge websites, apps, and digital solutions with precision, speed, and style.  
        Trusted by startups, brands, and entrepreneurs nationwide.
      </p>
      <div class="flex space-x-5 mt-3">
        <a href="https://github.com/apreezofficial" target="_blank" aria-label="GitHub" class="text-[#008080] hover:text-[#FF6F61] transition-transform transform hover:scale-110">
          <i class="bi bi-github text-2xl"></i>
        </a>
        <a href="https://x.com/apcodesphere" target="_blank" aria-label="Twitter" class="text-[#008080] hover:text-[#FF6F61] transition-transform transform hover:scale-110">
          <i class="bi bi-twitter text-2xl"></i>
        </a>
        <a href="https://tiktok.com/@apcodesphere" target="_blank" aria-label="TikTok" class="text-[#008080] hover:text-[#FF6F61] transition-transform transform hover:scale-110">
          <i class="bi bi-tiktok text-2xl"></i>
        </a>
        <a href="https://instagram.com/apcodesphere" target="_blank" aria-label="Instagram" class="text-[#008080] hover:text-[#FF6F61] transition-transform transform hover:scale-110">
          <i class="bi bi-instagram text-2xl"></i>
        </a>
        <a href="https://youtube.com/@apcodesphere" target="_blank" aria-label="YouTube" class="text-[#008080] hover:text-[#FF6F61] transition-transform transform hover:scale-110">
          <i class="bi bi-youtube text-2xl"></i>
        </a>
      </div>
    </div>

    <!-- Quick Links -->
    <div class="flex flex-col space-y-4 text-center md:text-left">
      <h2 class="text-xl font-semibold mb-3 text-[#008080]">Quick Links</h2>
      <nav class="flex flex-col space-y-2 text-gray-600 dark:text-gray-400">
        <a href="/" class="hover:text-[#FF6F61] transition-colors">Home</a>
        <a href="/projects" class="hover:text-[#FF6F61] transition-colors">Projects</a>
        <a href="/about.php" class="hover:text-[#FF6F61] transition-colors">About</a>
            <a href="/pricing.php" class="hover:text-[#FF6F61] transition-colors">Pricing</a>
        <a href="https://blog.preciousadedokun.com.ng" class="hover:text-[#FF6F61] transition-colors">Blog</a>
      </nav>
    </div>

    <!-- Contact Info -->
    <div class="flex flex-col space-y-4 text-center md:text-left max-w-xs">
      <h2 class="text-xl font-semibold mb-3 text-[#008080]">Contact</h2> 
      <p class="text-gray-600 dark:text-gray-400 flex items-center justify-center md:justify-start gap-3">
        <i class="bi bi-envelope-fill text-[#FF6F61] text-lg"></i>
        <span>apreezofficial@gmail.com</span>
      </p> 
      <p class="text-gray-600 dark:text-gray-400 flex items-center justify-center md:justify-start gap-3">
        <i class="bi bi-envelope-fill text-[#FF6F61] text-lg"></i>
        <span>admin@preciousadedokun.com.ng</span>
      </p>
      <p class="text-gray-600 dark:text-gray-400 flex items-center justify-center md:justify-start gap-3">
        <i class="bi bi-telephone-fill text-[#FF6F61] text-lg"></i>
        <span>+234 906 477 9856</span>
      </p>
      <p class="text-gray-600 dark:text-gray-400 flex items-center justify-center md:justify-start gap-3">
        <i class="bi bi-geo-alt-fill text-[#FF6F61] text-lg"></i>
        <span>Ekiti, Nigeria</span>
      </p>
    </div>
  </div>

  <div class="mt-12 border-t border-[#008080]/30 pt-6 text-center text-gray-500 dark:text-gray-400 text-sm select-text">
    &copy; 2025 APCodeSphere. All rights reserved. | The #1 Developer in Nigeria 🇳🇬
  </div>
</footer>

<!-- Floating WhatsApp Button -->
<a href="https://wa.me/2349064779856?text=Hi%20Precious%2C%20I%20want%20to%20hire%20you" 
   class="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg transition-transform transform hover:scale-110 z-50"
   target="_blank" aria-label="Chat on WhatsApp">
  <i class="bi bi-whatsapp text-3xl"></i>
</a>

<!-- JSON-LD Schema (Person + Developer Profile) -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Person",
  "name": "Precious Adedokun",
  "alternateName": "APCodeSphere",
  "description": "Best web developer in Nigeria, creating high-performance websites and apps with precision and creativity.",
  "jobTitle": "Full Stack Web Developer",
  "url": "https://preciousadedokun.com.ng",
  "email": "apreezofficial@gmail.com",
  "telephone": "+2349064779856",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Ekiti",
    "addressCountry": "Nigeria"
  },
  "sameAs": [
    "https://github.com/apreezofficial",
    "https://x.com/apcodesphere",
    "https://tiktok.com/@apcodesphere",
    "https://instagram.com/apcodesphere",
    "https://youtube.com/@apcodesphere"
  ],
  "knowsAbout": [
    "Web Development",
    "Frontend Development",
    "Backend Development",
    "Laravel",
    "React",
    "UI/UX",
    "SEO Optimization"
  ]
}
</script>
  
<style>  
  /* Initial hidden states */  
  .fade-section {  
    transition: opacity 0.8s ease, transform 0.8s ease;  
  }  
  .fade-in-left {  
    opacity: 1 !important;  
    transform: translateX(0) !important;  
  }  
  .fade-in-up {  
    opacity: 1 !important;  
    transform: translateY(0) !important;  
  }  
  .fade-in-right {  
    opacity: 1 !important;  
    transform: translateX(0) !important;  
  }  
</style>  
<script>const form = document.getElementById('contactForm');  
const submitBtn = document.getElementById('submitBtn');  const errors = {
name: document.getElementById('nameError'),
email: document.getElementById('emailError'),
message: document.getElementById('messageError'),
general: document.getElementById('generalError'),
success: document.getElementById('successMessage')
};

// Show error message helper
function showError(field, message) {
errors[field].querySelector('span').textContent = message;
errors[field].classList.remove('hidden');
}

// Hide error message helper
function hideError(field) {
errors[field].classList.add('hidden');
errors[field].querySelector('span').textContent = '';
}

// Hide all errors
function clearErrors() {
Object.keys(errors).forEach(key => hideError(key));
}

// Reset submit button UI
function resetSubmitBtn() {
submitBtn.disabled = false;
submitBtn.setAttribute('aria-busy', 'false');
submitBtn.innerHTML =   <span>Send Message</span>   <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">   <path d="M2.94 2.94a.75.75 0 011.06 0l12 12a.75.75 0 01-1.06 1.06L7.06 7.06l-4.12 4.13a.75.75 0 11-1.06-1.06l5-5z" />   </svg>  ;
}

form.addEventListener('input', e => {
if (errors[e.target.name]) hideError(e.target.name);
hideError('general');
hideError('success');
});

form.addEventListener('submit', async e => {
e.preventDefault();
clearErrors();

const name = form.name.value.trim();
const email = form.email.value.trim();
const message = form.message.value.trim();

let hasError = false;

if (!name) {
showError('name', 'Name is required.');
hasError = true;
}

if (!email) {
showError('email', 'Email is required.');
hasError = true;
} else if (!/\S+@\S+.\S+/.test(email)) {
showError('email', 'Email is invalid.');
hasError = true;
}

if (!message) {
showError('message', 'Message cannot be empty.');
hasError = true;
}

if (hasError) return;

submitBtn.disabled = true;
submitBtn.setAttribute('aria-busy', 'true');
submitBtn.innerHTML =   <svg class="animate-spin -ml-1 mr-3 h-6 w-6 text-[#0D0D0D]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true">   <circle class="opacity-25" cx="12" cy="12" r="10" stroke="#14B8A6" stroke-width="4"></circle>   <path class="opacity-75" fill="#14B8A6" d="M4 12a8 8 0 018-8v8H4z"></path>   </svg>Sending...  ;

try {
const formData = new FormData(form);

const response = await fetch('ajax/contact.php', {  
  method: 'POST',  
  body: formData,  
});  

if (!response.ok) throw new Error('Network response was not ok');  

const data = await response.json();  

if (data.success) {  
  errors.success.classList.remove('hidden');  
  form.reset();  
} else if (data.errors) {  
  // Show field-specific errors from backend  
  Object.entries(data.errors).forEach(([field, message]) => {  
    if (errors[field]) {  
      showError(field, message);  
    } else {  
      showError('general', message);  
    }  
  });  
} else if (data.message) {  
  // General error message  
  showError('general', data.message);  
} else {  
  showError('general', 'An unexpected error occurred. Please try again later.');  
}

} catch (error) {
showError('general', 'Failed to send message. Please check your connection and try again.');
console.error('Form submission error:', error);
} finally {
resetSubmitBtn();
}
});</script>

<script>  
  const slider = document.getElementById('testimonial-slider');  
  const slides = slider.children;  
  const totalSlides = slides.length;  
  let currentIndex = 0;  
  
  const prevBtn = document.getElementById('prevBtn');  
  const nextBtn = document.getElementById('nextBtn');  
  const dotsContainer = document.getElementById('dots');  
  
  // Create dots dynamically  
  for(let i = 0; i < totalSlides; i++) {  
    const dot = document.createElement('button');  
    dot.classList.add('w-4', 'h-4', 'rounded-full', 'bg-teal-300/60', 'hover:bg-teal-400', 'transition');  
    dot.setAttribute('aria-label', `Go to testimonial ${i+1}`);  
    dot.addEventListener('click', () => {  
      currentIndex = i;  
      updateSlider();  
      resetAutoSlide();  
    });  
    dotsContainer.appendChild(dot);  
  }  
  
  function updateSlider() {  
  slider.style.transform = `translateX(-${currentIndex * 100}%)`;  
  updateDots();  
}  
  
function updateDots() {  
  [...dotsContainer.children].forEach((dot, idx) => {  
    dot.classList.remove(  
      'bg-teal-500',  
      'scale-110',  
      'shadow-[0_0_8px_2px_rgba(72,187,120,0.7)]',  
      'bg-teal-300/60',  
      'dark:bg-teal-400/50'  
    );  
  
    if (idx === currentIndex) {  
      dot.classList.add(  
        'bg-teal-500',  
        'scale-110',  
        'shadow-[0_0_8px_2px_rgba(72,187,120,0.7)]'  
      );  
    } else {  
      dot.classList.add('bg-teal-300/60', 'dark:bg-teal-400/50');  
    }  
  });  
}  
  
  prevBtn.addEventListener('click', () => {  
    currentIndex = (currentIndex === 0) ? totalSlides - 1 : currentIndex - 1;  
    updateSlider();  
    resetAutoSlide();  
  });  
  
  nextBtn.addEventListener('click', () => {  
    currentIndex = (currentIndex === totalSlides - 1) ? 0 : currentIndex + 1;  
    updateSlider();  
    resetAutoSlide();  
  });  
  
  let slideInterval = setInterval(() => {  
    currentIndex = (currentIndex === totalSlides - 1) ? 0 : currentIndex + 1;  
    updateSlider();  
  }, 4000);  
  
  function resetAutoSlide() {  
    clearInterval(slideInterval);  
    slideInterval = setInterval(() => {  
      currentIndex = (currentIndex === totalSlides - 1) ? 0 : currentIndex + 1;  
      updateSlider();  
    }, 6000);  
  }  
  
  // Initialize  
  updateSlider();  
</script>  <script>  
  document.addEventListener('DOMContentLoaded', () => {  
    const cards = document.querySelectorAll('#projects .group');  
    const observer = new IntersectionObserver(entries => {  
      entries.forEach(entry => {  
        if (entry.isIntersecting) {  
          entry.target.classList.add('opacity-100', 'translate-y-0');  
        }  
      });  
    }, { threshold: 0.1 });  
  
    cards.forEach(card => {  
      card.classList.add('opacity-0', 'translate-y-6', 'transition-all', 'duration-700');  
      observer.observe(card);  
    });  
  });  
</script>  <script>  
  const progressBars = document.querySelectorAll('.progress');  
  let skillsAnimated = false;  
  
  function isInView(el) {  
    const rect = el.getBoundingClientRect();  
    return rect.top <= window.innerHeight * 0.8;  
  }  
  
  function animateBars() {  
    if (!skillsAnimated && isInView(document.getElementById('skills'))) {  
      progressBars.forEach(bar => {  
        const width = bar.getAttribute('data-width');  
        bar.style.width = width;  
      });  
      skillsAnimated = true;  
    }  
  }  
  
  window.addEventListener('scroll', animateBars);  
  window.addEventListener('load', animateBars);  
</script>  <script>  
  const counters = document.querySelectorAll('.counter');  
  let started = false;  
  
  function runCounters() {  
    const duration = 1000; // total animation time in ms  
    const startTime = performance.now();  
  
    function update() {  
      const now = performance.now();  
      const elapsed = now - startTime;  
      const progress = Math.min(elapsed / duration, 1); // from 0 to 1  
  
      counters.forEach(counter => {  
        const target = +counter.getAttribute('data-target');  
        // Calculate current count based on progress  
        counter.innerText = Math.floor(progress * target);  
      });  
  
      if (progress < 1) {  
        requestAnimationFrame(update);  
      } else {  
        // Ensure all counters show their exact target value at the end  
        counters.forEach(counter => {  
          counter.innerText = counter.getAttribute('data-target');  
        });  
      }  
    }  
  
    requestAnimationFrame(update);  
  }  
  
  function isInViewport(element) {  
    const rect = element.getBoundingClientRect();  
    return rect.top <= (window.innerHeight || document.documentElement.clientHeight);  
  }  
  
  window.addEventListener('scroll', () => {  
    const statsSection = document.getElementById('stats');  
    if (!started && isInViewport(statsSection)) {  
      started = true;  
      runCounters();  
    }  
  });  
</script>  <script>  
  document.addEventListener('DOMContentLoaded', () => {  
    const observerOptions = {  
      root: null,  
      rootMargin: '0px',  
      threshold: 0.1, // trigger when 10% visible  
    };  
  
    const observer = new IntersectionObserver((entries, observer) => {  
      entries.forEach(entry => {  
        if (entry.isIntersecting) {  
          const el = entry.target;  
          // Determine animation direction by original translate  
          if (el.classList.contains('translate-x-[-20px]')) {  
            el.classList.add('fade-in-left');  
          } else if (el.classList.contains('translate-x-[20px]')) {  
            el.classList.add('fade-in-right');  
          } else if (el.classList.contains('translate-y-[20px]')) {  
            el.classList.add('fade-in-up');  
          } else {  
            // default fade-in-up  
            el.classList.add('fade-in-up');  
          }  
          observer.unobserve(el); // animate only once  
        }  
      });  
    }, observerOptions);  
  
    document.querySelectorAll('.fade-section').forEach(section => {  
      observer.observe(section);  
    });  
  });  
</script>  <script>  
document.addEventListener("DOMContentLoaded", () => {  
  const elements = document.querySelectorAll('#loadin');  
  
  elements.forEach(el => {  
    const originalText = el.textContent.trim();  
    el.textContent = "";  
  
    const observer = new IntersectionObserver((entries, obs) => {  
      entries.forEach(entry => {  
        if (entry.isIntersecting) {  
          el.classList.add("visible");  
          let i = 0;  
  
          function typeLetter() {  
            if (i < originalText.length) {  
              el.textContent += originalText[i];  
              i++;  
              setTimeout(typeLetter, 35); // speed per letter  
            }  
          }  
  
          typeLetter();  
          obs.unobserve(el); // Only run once per element  
        }  
      });  
    });  
  
    observer.observe(el);  
  });  
});  
</script>
<script>
  lucide.createIcons();
</script>
</body>
</html>